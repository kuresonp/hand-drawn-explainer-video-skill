---
name: hand-drawn-explainer-video
description: >
  Turns a voice-over (audio file or pasted script) into a finished hand-drawn "live-writing"
  explainer video in React + Remotion, presented by a recurring anime-girl character in a red
  sweater (the "girl rig", never a stick figure). It transcribes the narration to word-level
  timestamps, directs it into visual beats (props that draw themselves, mood and pose changes,
  stage position), assembles a storyboard, and renders a 9:16 video with word-by-word
  yellow-pill captions. Use this whenever the user provides or mentions a voice-over, narration,
  script or transcript and wants an animated / whiteboard / doodle / hand-drawn / explainer /
  Shorts / Reels / TikTok video, or asks to animate a script with a character, even if they never
  say "Remotion" or "skill".
---

# Hand-Drawn Live-Writing Explainer Video

The user brings a voice-over. You deliver a rendered video in which props draw themselves in sync
with the speech, while one recurring presenter, the **girl rig** (an ~18-year-old anime girl, red
sweater and skirt), reacts with moods and poses. The look is a reverse-engineered
hand-inked whiteboard style; the full forensic notes are in `references/reverse-engineered-spec.md`.

## The pipeline (run in this order)

```
voiceover.mp3 ──transcribe.py──▶ whisper_words.json ──words_to_timings.mjs──▶ words.json (+ .indexed.txt)
                                                                                      │
                                   you read the indexed transcript and DIRECT it      ▼
                                                              beats.json ──assemble_storyboard.mjs──▶ storyboard.json
                                                                                                          │ validate (automatic)
                                                                                           npm run render ▼
                                                                                                   out/video.mp4
```

### Step 0 - Set up the project
1. Copy `templates/remotion-starter/` to a working folder and copy this skill's `scripts/` next to it
   (`cp -r scripts <project>/scripts`). Run `npm install` (needs Node 18+; rendering needs ffmpeg/Chromium,
   which Remotion downloads on first render).
2. Put the voice-over in `<project>/public/voiceover.mp3` (any format ffmpeg reads).
3. The starter ships with a working example (`examples/script.txt`, `examples/beats.json`, a generated
   `src/data/storyboard.json`), so `npm run dev` previews immediately. Overwrite `storyboard.json` in Step 3.

### Step 1 - Transcribe with word-level timestamps
- **Audio provided:** `python3 scripts/transcribe.py public/voiceover.mp3 --out src/data/whisper_words.json`
  (uses faster-whisper, falls back to openai-whisper; `--lang` if auto-detect guesses wrong). Then
  `node scripts/words_to_timings.mjs --whisper src/data/whisper_words.json --out src/data/words.json`.
- **No transcription backend installed** (transcribe.py exits with code 2): try `pip install faster-whisper` first.
  If that is impossible, ask the user to paste the script and use the heuristic route below with
  `--duration` set to the audio length (`ffprobe -v error -show_entries format=duration -of csv=p=0 public/voiceover.mp3`).
- **Only text, no audio yet:** `node scripts/words_to_timings.mjs --text script.txt --out src/data/words.json`
  (about 155 wpm, +6 frames after commas, +12 after sentence ends). Tell the user timings are estimated and
  will be re-aligned once the real audio arrives (re-run Step 1 with the audio, then re-assemble; beats keep working
  because they reference word *indexes*, not frames, as long as the transcript text is unchanged).
- Always read the transcript back and fix obvious mis-hearings (names, numbers) in `words.json` before directing,
  since captions show these words verbatim.

### Step 2 - Direct the video (this is your creative job)
Open `src/data/words.json.indexed.txt` (e.g. `[0] YouTube [1] just ...`). Write `beats.json`, an array of beats,
each starting at a word index (`fromWord`); a beat ends where the next begins. Read
`references/voiceover-to-storyboard-guide.md` first; it holds the full mapping tables. The essentials:

- **One idea per beat, 2.5-4.5 s (75-135 frames)**; cut at clause boundaries. Never leave one static drawing
  on screen longer than 4.5 s; split the thought and change prop, position, pose or mood.
- **Pick the prop from the rhetorical intent:** numbers -> `stat-callout`; a twist or risk -> `warning-storm`;
  a headline or quote -> `headline-card`; growth or a crash -> `trend-chart`; "X vs Y" -> `comparison-scale`;
  rules or lists -> `checklist-card`; steps -> `process-flow`; pure reaction or outro -> `none`.
- **Direct the girl like an actor:** choose `characterExpression` from the speaker's feeling (happy, worry, shock,
  scared, angry, sad, smirk, thinking) and `characterPose` from what she is doing (point at the prop, celebrate,
  thinking with a hand on her chin, wave). Alternate `characterPos` (`left`/`center`/`right`) every 1-3 beats
  and place her opposite the prop's visual weight.
- Beat shape: `{ "id", "fromWord", "propKind", "propData", "characterPos", "characterPose", "characterExpression", "facing"?, "sweatDrop"? }`
  (see `examples/beats.json`; prop fields are documented in `src/types/storyboard.ts`).

### Step 3 - Assemble and validate
```
node scripts/assemble_storyboard.mjs --words src/data/words.json --beats beats.json \
     --title "<title>" --audio voiceover.mp3 --out src/data/storyboard.json
```
It computes every beat's frames and narration, writes the storyboard and lints it (contiguity, beat length,
unknown props/poses, character parked on one side, pointing off-screen). Fix every ERROR; fix warnings unless
there is a reason not to. `npm run validate` re-runs the lint.

### Step 4 - Render and verify
1. Preview: `npm run dev`. Grab stills at beat boundaries: `npx remotion still src/index.ts HandDrawnExplainer out/still.png --frame=<n>`.
2. Check each still: prop strokes drawn before fills fade in; no text outside the 720 px width; captions are
   readable at the bottom; the girl does not overlap props (her thought bubble reaches y~560, so keep props
   above that on `thinking` beats); she points *toward* the prop; mood matches the line being spoken.
3. Render: `npm run render` -> `out/video.mp4` (30 fps, 720x1280, voice-over muxed in via `<Audio>`).
4. Deliver the mp4 and, when useful, the project folder so the user can tweak beats and re-render.

## Visual constitution (keep these when editing the template)

- **Format:** 720x1280 vertical (9:16), 30 fps. 16:9 is not built in; it needs the stage zones below re-laid out.
- **Paper:** radial parchment vignette `#EEE4D2` -> `#D3C9B7`; never pure white or black.
- **Line boil (7.5 Hz):** an SVG `feTurbulence` + `feDisplacementMap(scale 2.4)` filter whose `seed` changes every 4 frames.
  It wraps everything inside the SVG: strokes, fills, the lettering printed on cards, and the girl. Only the HTML
  captions stay crisp (measured on the reference video: the caption zone never changes between boil seeds, while card
  lettering does). See `Composition.tsx`.
- **Pen draw-on:** every box, chart, bubble and rule animates on with `pathLength={100}` + `strokeDashoffset`
  over 12-20 frames (`DrawPath`); fills fade in after 65% of the stroke; card text types out character by character (`TypeText`).
- **Palette:** ink `#1E1B18`; hero red `#E03A3E` (skirt `#A82830`); skin `#FADCBF`; hair `#2B2230`; alert/crash `#D5433D`;
  bot/growth `#AAD39B` / `#4CA64C`; caption pill `#E4C365`; paper card `#FBF7EE`.
- **Stage zones (720x1280):** props `y 90-580`; presenter feet at `y 1010` (rig ~380 px tall, head top ~630) at
  `x = 155 / 360 / 565`; captions bottom zone `y ~1110-1200`.
- **Determinism:** derive all motion from `useCurrentFrame()` + `interpolate()`/`spring()`. No `setInterval`,
  `requestAnimationFrame` or CSS `@keyframes`. Inside `<svg>` use `<Sequence layout="none">`; the default wraps
  children in a `<div>`, which SVG will not draw.

## The hero: girl rig
`src/components/GirlRig.tsx` is a pure-SVG puppet (mirrorable, blinking, breathing,
swaying hair; no lip-sync, the mouth only changes with the mood). It replaces the old stick figure; do not reintroduce one. Moods: smile, happy, shock, worry, sad,
smirk, angry, scared, thinking. Arm poses: down, point, cheer, fing, chin, support, wave. `GirlCharacter.tsx` maps the
storyboard's `characterPose` / `characterExpression` onto them and handles the 14-frame slide between stage positions.
Details, parameters and how to add a mood, pose or outfit: `references/girl-rig-spec.md`.

## Troubleshooting
- **`@remotion/google-fonts/Fredoka` not found:** run `npx remotion add @remotion/google-fonts` (or `npm i @remotion/google-fonts`
  at the same version as `remotion`), or delete the `loadFont()` call and rely on the fallback font stack in `FONT`.
- **"Version mismatch" between Remotion packages:** pin `remotion`, `@remotion/cli`, `@remotion/google-fonts` to one exact version (`npx remotion versions`).
- **Captions out of sync with the audio:** the timings came from the heuristic route; re-run Step 1 with real audio.
- **A needed visual has no prop kind** (e.g. a broom sweeping bots into a bin): add a component to `Props.tsx`,
  extend `PropKind` in `types/storyboard.ts`, add the name to `PROPS` in `scripts/validate_storyboard.mjs`, and use the same
  `DrawPath` / `PopGroup` / `TypeText` primitives so it stays in style.
