#!/usr/bin/env node
// Lint a storyboard.json against the skill's directing rules.  node scripts/validate_storyboard.mjs src/data/storyboard.json
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const PROPS = ['none', 'stat-callout', 'checklist-card', 'comparison-scale', 'trend-chart', 'warning-storm', 'headline-card', 'process-flow'];
const POSES = ['idle', 'point', 'point-left', 'point-right', 'point-up', 'celebrate', 'shocked', 'thinking', 'wave'];
const MOODS = ['smile', 'happy', 'shock', 'worry', 'sad', 'smirk', 'angry', 'scared', 'thinking', 'excited', 'worried', 'skeptical', 'shocked'];
const POS = ['left', 'center', 'right'];

export function validate(sb) {
  const errors = [];
  const warnings = [];
  const { beats = [], words = [], totalFrames = 0 } = sb;
  if (!beats.length) errors.push('no beats');
  if (!words.length) errors.push('no words');

  beats.forEach((b, i) => {
    const tag = `beat ${b.id ?? i}`;
    if (!PROPS.includes(b.propKind)) errors.push(`${tag}: unknown propKind "${b.propKind}"`);
    if (!POSES.includes(b.characterPose)) errors.push(`${tag}: unknown characterPose "${b.characterPose}"`);
    if (!MOODS.includes(b.characterExpression)) errors.push(`${tag}: unknown characterExpression "${b.characterExpression}"`);
    if (!POS.includes(b.characterPos)) errors.push(`${tag}: unknown characterPos "${b.characterPos}"`);
    if (i === 0 && b.startFrame !== 0) errors.push(`${tag}: first beat must start at frame 0`);
    if (i > 0 && b.startFrame !== beats[i - 1].endFrame) errors.push(`${tag}: not contiguous with previous beat (${beats[i - 1].endFrame} -> ${b.startFrame})`);
    if (b.endFrame <= b.startFrame) errors.push(`${tag}: endFrame <= startFrame`);
    if (b.endFrame > totalFrames) errors.push(`${tag}: ends after totalFrames`);
    const len = b.endFrame - b.startFrame;
    if (len > 135) warnings.push(`${tag}: ${(len / 30).toFixed(1)}s on one drawing - split it (max 4.5s)`);
    if (len < 60 && i < beats.length - 1) warnings.push(`${tag}: only ${(len / 30).toFixed(1)}s - merge with a neighbour (min ~2s)`);
    if (b.characterPos === 'left' && b.characterPose === 'point-left') warnings.push(`${tag}: points off-screen (left character should point right/up)`);
    if (b.characterPos === 'right' && b.characterPose === 'point-right') warnings.push(`${tag}: points off-screen (right character should point left/up)`);
    if (b.propKind === 'headline-card' && (b.propData?.headline ?? '').length > 48) warnings.push(`${tag}: headline > 48 chars may overflow the card`);
    if (b.propKind === 'checklist-card' && (b.propData?.items?.length ?? 0) > 5) warnings.push(`${tag}: more than 5 checklist items`);
    if (b.propKind === 'process-flow' && (b.propData?.items?.length ?? 0) > 3) warnings.push(`${tag}: more than 3 process steps`);
    if (i >= 2 && [0, 1, 2].every((k) => beats[i - k].characterPos === b.characterPos)) warnings.push(`${tag}: character stayed ${b.characterPos} for 3 beats - alternate sides`);
  });

  words.forEach((w, i) => {
    if (w.endFrame < w.startFrame) errors.push(`word ${i} "${w.word}": end before start`);
    if (i > 0 && w.startFrame < words[i - 1].startFrame) errors.push(`word ${i} "${w.word}": out of order`);
  });
  return { errors, warnings };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const file = process.argv[2] ?? 'src/data/storyboard.json';
  const { errors, warnings } = validate(JSON.parse(fs.readFileSync(file, 'utf8')));
  warnings.forEach((w) => console.log('warn  ' + w));
  errors.forEach((e) => console.log('ERROR ' + e));
  console.log(`${errors.length} errors, ${warnings.length} warnings`);
  process.exit(errors.length ? 1 : 0);
}
