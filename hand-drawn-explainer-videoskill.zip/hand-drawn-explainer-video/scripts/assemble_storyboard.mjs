#!/usr/bin/env node
// Merge directed beats (word-index ranges) with word timings into the storyboard Remotion renders.
//
//   node scripts/assemble_storyboard.mjs --words src/data/words.json --beats beats.json \
//        --title "My video" [--audio voiceover.mp3] --out src/data/storyboard.json
//
// beats.json = [{ "id","fromWord", "propKind","propData","characterPos","characterPose","characterExpression",
//                 "facing"?, "sweatDrop"? }, ...]   (fromWord = index in words.json.indexed.txt)
// A beat runs from its first word until the next beat's first word; the last beat runs to totalFrames.
import fs from 'node:fs';
import { validate } from './validate_storyboard.mjs';

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, all) => (a.startsWith('--') ? [...acc, [a.slice(2), all[i + 1]]] : acc), []));
if (!args.words || !args.beats || !args.out) {
  console.error('usage: assemble_storyboard.mjs --words words.json --beats beats.json [--title t] [--audio file.mp3] --out storyboard.json');
  process.exit(1);
}
const { words, totalFrames } = JSON.parse(fs.readFileSync(args.words, 'utf8'));
const beatsIn = JSON.parse(fs.readFileSync(args.beats, 'utf8'));

const beats = beatsIn.map((b, i) => {
  const next = beatsIn[i + 1];
  const startFrame = i === 0 ? 0 : words[b.fromWord].startFrame;
  const endFrame = next ? words[next.fromWord].startFrame : totalFrames;
  const toWord = next ? next.fromWord : words.length;
  const { fromWord, ...rest } = b;
  return {
    ...rest,
    startFrame,
    endFrame,
    narration: words.slice(b.fromWord, toWord).map((w) => w.word).join(' '),
    propData: b.propData ?? {},
  };
});

const storyboard = { title: args.title ?? 'Explainer', ...(args.audio ? { audioFile: args.audio } : {}), fps: 30, width: 720, height: 1280, totalFrames, beats, words };
fs.writeFileSync(args.out, JSON.stringify(storyboard, null, 2));

const { errors, warnings } = validate(storyboard);
warnings.forEach((w) => console.log('warn  ' + w));
errors.forEach((e) => console.log('ERROR ' + e));
console.log(`${beats.length} beats, ${totalFrames} frames -> ${args.out} (${errors.length} errors, ${warnings.length} warnings)`);
process.exit(errors.length ? 1 : 0);
