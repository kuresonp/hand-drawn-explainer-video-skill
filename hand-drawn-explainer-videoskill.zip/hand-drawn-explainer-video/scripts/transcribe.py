#!/usr/bin/env python3
"""Transcribe a voice-over into word-level timestamps (seconds).

Usage:
  python3 scripts/transcribe.py public/voiceover.mp3 --out src/data/whisper_words.json [--model small] [--lang en]

Tries faster-whisper first, then openai-whisper. Needs ffmpeg on PATH for mp3/m4a/mp4 input.
Install one of:  pip install faster-whisper     (recommended)   |   pip install openai-whisper
Output: {"text": "...", "duration": <seconds>, "words": [{"word": "Hello", "start": 0.12, "end": 0.48}, ...]}
Exit code 2 = no transcription backend installed (fall back to a pasted script + words_to_timings.mjs --text).
"""
import argparse
import json
import subprocess
import sys


def audio_duration(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", path],
            capture_output=True, text=True, check=True,
        ).stdout.strip()
        return round(float(out), 3)
    except Exception:
        return None


def run_faster_whisper(path, model, lang):
    from faster_whisper import WhisperModel

    m = WhisperModel(model, device="auto", compute_type="auto")
    segments, _ = m.transcribe(path, word_timestamps=True, language=lang, vad_filter=True)
    words = []
    for seg in segments:
        for w in seg.words or []:
            words.append({"word": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)})
    return words


def run_openai_whisper(path, model, lang):
    import whisper

    m = whisper.load_model(model)
    res = m.transcribe(path, word_timestamps=True, language=lang)
    words = []
    for seg in res["segments"]:
        for w in seg.get("words", []):
            words.append({"word": w["word"].strip(), "start": round(w["start"], 3), "end": round(w["end"], 3)})
    return words


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("audio")
    ap.add_argument("--out", default="src/data/whisper_words.json")
    ap.add_argument("--model", default="small")
    ap.add_argument("--lang", default=None, help="language code, e.g. en (default: auto-detect)")
    a = ap.parse_args()

    words = None
    errors = []
    for name, fn in (("faster-whisper", run_faster_whisper), ("openai-whisper", run_openai_whisper)):
        try:
            words = fn(a.audio, a.model, a.lang)
            print(f"transcribed with {name}", file=sys.stderr)
            break
        except ImportError:
            errors.append(f"{name}: not installed")
        except Exception as e:  # keep going so the other backend gets a chance
            errors.append(f"{name}: {e}")
    if words is None:
        print("No transcription backend worked:\n  " + "\n  ".join(errors), file=sys.stderr)
        print("Install with: pip install faster-whisper", file=sys.stderr)
        sys.exit(2)

    words = [w for w in words if w["word"]]
    payload = {"text": " ".join(w["word"] for w in words), "duration": audio_duration(a.audio), "words": words}
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f"{len(words)} words -> {a.out}")


if __name__ == "__main__":
    main()
