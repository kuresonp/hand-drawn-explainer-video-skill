#!/usr/bin/env node
// Convert a transcript into frame-accurate WordTiming[] (30 fps) + an indexed word list for directing.
//
//   node scripts/words_to_timings.mjs --whisper src/data/whisper_words.json --out src/data/words.json
//   node scripts/words_to_timings.mjs --text script.txt [--duration 49.2] [--wpm 155] --out src/data/words.json
//
// --whisper : output of transcribe.py (seconds)  -> exact timings
// --text    : plain script, no audio yet / no Whisper -> heuristic timings (~155 wpm, +6f comma, +12f period);
//             with --duration (seconds of the real voice-over) the timings are stretched to fit it.
// Writes <out> = { fps, totalFrames, words:[{word,startFrame,endFrame}] } and <out>.indexed.txt ("[0] YouTube [1] just ...").
import fs from 'node:fs';

const FPS = 30;
const args = Object.fromEntries(
  process.argv.slice(2).reduce((acc, a, i, all) => (a.startsWith('--') ? [...acc, [a.slice(2), all[i + 1]?.startsWith('--') || all[i + 1] === undefined ? true : all[i + 1]]] : acc), []),
);
if (!args.out || (!args.whisper && !args.text)) {
  console.error('usage: words_to_timings.mjs (--whisper words.json | --text script.txt [--duration s] [--wpm 155]) --out words.json');
  process.exit(1);
}

let words = [];
if (args.whisper) {
  const raw = JSON.parse(fs.readFileSync(args.whisper, 'utf8'));
  const list = Array.isArray(raw) ? raw : raw.words;
  words = list.map((w) => ({ word: String(w.word).trim(), start: Math.round(w.start * FPS), end: Math.round(w.end * FPS) })).filter((w) => w.word);
  words.forEach((w, i) => {
    const next = words[i + 1];
    w.end = Math.max(w.end, w.start + 3);
    if (next) w.end = Math.min(w.end, Math.max(w.start + 3, next.start - 1));
  });
} else {
  const tokens = fs.readFileSync(args.text, 'utf8').split(/\s+/).filter(Boolean);
  const wpm = Number(args.wpm) || 155;
  const perWord = (FPS * 60) / wpm;
  const avgLen = tokens.reduce((s, t) => s + Math.max(2, t.replace(/\W/g, '').length), 0) / tokens.length;
  let cursor = 4;
  for (const t of tokens) {
    const len = Math.max(2, t.replace(/\W/g, '').length);
    const dur = Math.max(5, Math.round((len / avgLen) * perWord));
    words.push({ word: t, start: cursor, end: cursor + dur - 1 });
    cursor += dur + (/[.!?]$/.test(t) ? 12 : /[:;]$/.test(t) ? 8 : /,$/.test(t) ? 6 : 0);
  }
  if (args.duration) {
    const target = Number(args.duration) * FPS - 15;
    const k = target / words[words.length - 1].end;
    words.forEach((w) => { w.start = Math.round(w.start * k); w.end = Math.max(w.start + 3, Math.round(w.end * k)); });
  }
}

const out = words.map((w) => ({ word: w.word, startFrame: w.start, endFrame: w.end }));
const tail = args.duration ? 15 : 36;
const totalFrames = Math.max(out[out.length - 1].endFrame + tail, args.duration ? Math.round(Number(args.duration) * FPS) : 0);
fs.writeFileSync(args.out, JSON.stringify({ fps: FPS, totalFrames, words: out }, null, 2));
fs.writeFileSync(args.out + '.indexed.txt', out.map((w, i) => `[${i}] ${w.word}`).join(' ') + '\n');
console.log(`${out.length} words, ${totalFrames} frames (${(totalFrames / FPS).toFixed(1)}s) -> ${args.out}`);
console.log(`indexed transcript for directing -> ${args.out}.indexed.txt`);
