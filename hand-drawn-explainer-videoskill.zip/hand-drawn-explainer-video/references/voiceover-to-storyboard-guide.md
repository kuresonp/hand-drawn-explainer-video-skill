# Voiceover-to-Storyboard Directing Guide

Read this before writing `beats.json`. Names below are the real `PropKind`, `CharacterPose` and mood values
used by the template (`src/types/storyboard.ts`); the validator rejects anything else.

## 1. Spoken intent -> prop

| Spoken cue / rhetorical intent | `propKind` | What the viewer sees | `propData` |
| :--- | :--- | :--- | :--- |
| Big number, statistic, metric, timeframe | `stat-callout` | number counts up from 0, red underline draws, label types, optional calendar badge | `statNumber` ("130,000", "$4.2M", "73%"), `statLabel`, `badgeText` |
| Warning, risk, twist, "but here's the problem" | `warning-storm` | storm cloud pops, rain and lightning draw, red `!` | `headline` (optional red line) |
| News, announcement, quote, post, headline | `headline-card` | newspaper border draws, masthead + headline type out | `badgeText` (masthead), `headline`, `subheadline` (red) |
| Growth, drop, crash, analytics | `trend-chart` | axes draw, curve plots, crash adds red drop + arrow + impact star | `trendDirection` (`up`/`surge`/`down`/`crash`), `chartLabel`, `headline` |
| Trade-off, "X vs Y", "matters more than" | `comparison-scale` | beam tips toward the heavier side | `leftLabel`, `rightLabel`, `heavier`, `badgeText` ("?" over the lighter side) |
| Rules, updates, steps as a list | `checklist-card` | clipboard draws, ticks appear every 10 frames | `headline`, `items` (max 5) |
| Workflow, "first... then... finally" | `process-flow` | up to 3 numbered cards joined by arrows | `headline`, `items` (max 3) |
| Reaction, transition, outro, anything the girl can carry alone | `none` | just the presenter | - |

Ideas with no matching prop (cleanup, a tightrope, an easel...) are fine to add as new components; see
SKILL.md "Troubleshooting". Until then use the closest prop (cleanup -> `stat-callout` of the count removed).

## 2. Beats
- 75-135 frames (2.5-4.5 s) each; the validator warns outside 60-135. Cut at clause or sentence boundaries.
- Opening beat: the hook with the strongest prop; closing beat: usually `none` with a wave or celebrate.
- Keep on-card text short: headlines <= 48 characters, checklist items <= 22 characters, labels <= 14 characters.
- Prefer changing *something* every beat: the prop, her stage position, her pose, or her mood.

## 3. Directing the girl

### Mood (`characterExpression`) from what the speaker means
| Meaning of the line | mood |
| :--- | :--- |
| Good news, success, a win | `happy` (eyes closed, big smile) or `smile` (calm) |
| Surprise, a startling number | `shock` |
| Concern, "but", a problem appears | `worry` (adds a sweat drop) |
| Real fear, danger, a crash | `scared` (white eyes, trembling) |
| Outrage, a villain, injustice | `angry` (slanted brows, gritted teeth, anger mark) |
| Loss, disappointment, bad outcome | `sad` |
| Irony, "of course", knowing sarcasm, the sly aside | `smirk` |
| A question to the audience, weighing options | `thinking` (thought bubble with dots) |
Legacy aliases still work: `excited`->happy, `worried`->worry, `skeptical`->smirk, `shocked`->shock.

### Pose (`characterPose`)
| Pose | Arms | Use when |
| :--- | :--- | :--- |
| `idle` | both down | listening beats, neutral narration |
| `point` | one arm points the way she faces | introducing the prop on screen |
| `point-up` | finger raised | "here's the key point" |
| `celebrate` | both arms up | wins, big numbers, hype |
| `shocked` | both arms up | pair with `shock` / `scared` |
| `thinking` | hand under chin, other arm supporting the elbow | questions; pair with `thinking` or `smirk` |
| `wave` | waving | greeting and sign-off |
`point-left` / `point-right` still work (they force her to face that way) but prefer `point` + staging.

### Staging
- Stage x: `left` 155, `center` 360, `right` 565. Alternate every 1-3 beats; never three beats on the same side.
- She faces the centre of the frame by default, so `point` aims at the prop. Override with `facing: "left" | "right"` only for a reason.
- Put her opposite the prop's weight; on `thinking` beats keep props above y~560 (the thought bubble).
- `sweatDrop: true` adds a drop in any mood (it is automatic for `shock`, `worry`, `scared`).
- There is no lip-sync: the mouth only follows the mood.

## 4. Captions
Captions chunk into lines of 2-4 words (<= 23 characters) with the active word in a `#E4C365` pill. This is automatic;
fix awkward line breaks by editing the transcript spelling (e.g. join "130,000" or "AI-generated" into one token).

## 5. Worked example
`templates/remotion-starter/examples/script.txt` + `examples/beats.json` direct a 26 s video in nine beats:
stat -> stat -> headline card -> storm -> alert card -> crash chart -> scale -> checklist -> outro.
Copy its structure when you are unsure.
