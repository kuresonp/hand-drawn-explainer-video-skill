# Forensic Reverse-Engineering Spec (iart-shared-video.mp4)

> **Note (updated):** this document records the original video as analysed. Its presenter was an orange-shirt stick figure; this skill
> replaces that presenter with the red-sweater anime girl rig (`references/girl-rig-spec.md`). Everything else here (paper, line boil,
> palette, beat structure) still applies. The "Presenter Orange" colour is now only a reference for the original; use the hero red `#E03A3E`.


## 1. Container & Stream Telemetry
- **Generator**: `Made with Remotion 4.0.532`
- **Resolution**: `720 × 1280` (9:16 vertical short-form)
- **Frame Rate**: `30 fps` exact (`1,470` frames / `49.00s`)
- **Audio**: AAC LC Stereo, `48,000 Hz`, `317 kbps`

## 2. Empirical Line-Boil Measurement
Pixel-difference testing across static hold frames (`1445–1455`) measured:
- Frames `1445->1446`, `1446->1447`: ~3,500 changed pixels (subtle micro-elements)
- **Frame `1447->1448`**: **24,964 changed pixels**
- Frames `1448->1451`: ~3,200 changed pixels
- **Frame `1451->1452`**: **23,909 changed pixels**

Because `1448 % 4 === 0` and `1452 % 4 === 0`, the entire stroke layer updates its displacement seed every **4 frames** (`Math.floor(frame / 4) % 4` = **7.5 Hz**).

## 3. Exact Color System
| Role | Hex | Usage |
| :--- | :--- | :--- |
| Parchment Center | `#EEE4D2` | Radial gradient center |
| Vignette Edge | `#D3C9B7` | Outer paper darkening |
| Charcoal Ink | `#1E1B18` | All outlines, stick limbs, caption text |
| Presenter Orange | `#EF8A3C` | Hero shirt fill |
| Warm Peach Skin | `#FADCBF` | Faces & hands |
| Crimson Alert | `#D5433D` | YouTube logo, crashes, cross-outs, crosshairs |
| AI Sage Green | `#AAD39B` | Bot heads & growth curves |
| Mustard Highlight | `#E4C365` | Active spoken word pill |
| Animator Purple | `#9E7BB5` | Secondary character tunics |
| Support Green | `#4CA64C` | Support agent shirt & checkmarks |

## 4. 15-Beat Scene Breakdown (Frames 0–1470)
1. **0–78 (0.0s–2.6s)** `purge-sweep`: YouTube logo pops; shelf draws left-to-right; broom sweeps 3 dead AI TV-bots into trash can.
2. **78–150 (2.6s–5.0s)** `counter-calendar`: Counter eases `0 -> 130,000` "channels deleted"; calendar flips `5 -> 6 MONTHS`.
3. **150–230 (5.0s–7.7s)** `storm-alert`: Celebration stars fade into grey storm cloud, rain, yellow lightning, red `!`, character sweat drop.
4. **230–315 (7.7s–10.5s)** `newspaper`: Border draws clockwise, `THE DAILY TUBE` masthead + typewriter headline `YOUTUBE PURGES AI SLOP!` + corner stars.
5. **315–365 (10.5s–12.2s)** `brain-rot`: Pink brain draws on, grows green drips + buzzing flies, slashed by bold red `X`.
6. **365–445 (12.2s–14.8s)** `money-vs-passion`: Secondary creator beside crossed-out `$` money bag replaced by glowing heart.
7. **445–505 (14.8s–16.8s)** `caveat-magnify`: Large red `*` + summary bars + zooming magnifying glass.
8. **505–615 (16.8s–20.5s)** `monitor-trio`: 3 creator monitors age (beard grows), then crack with red `AI` stamps & hanging `AI?` tag.
9. **615–735 (20.5s–24.5s)** `crash-chart`: `KurtzKatzok` cat card types out; green `views` line climbs then crashes in red with star impact + down arrow.
10. **735–830 (24.5s–27.7s)** `support-desk`: Green-shirt rep at desk linked by blue dashed arc; speech bubble reveals `AI` robot.
11. **830–990 (27.7s–33.0s)** `animator-easel`: Purple-beret animator paints bouncing red dot at easel under scrolling filmstrip while red crosshairs lock on.
12. **990–1060 (33.0s–35.3s)** `ai-shrink-check`: AI robot shrinks away as green checkmark draws on.
13. **1060–1190 (35.3s–39.7s)** `tightrope-creators`: 3 heart-crowned creators wobble on sagging tightrope dropping `$` coins over hazard spikes.
14. **1190–1290 (39.7s–43.0s)** `balance-scale`: Scale tips heavily toward red Heart over questioning `?` AI robot.
15. **1290–1470 (43.0s–49.0s)** `partner-clipboard`: Clipboard draws `PARTNER PROGRAM`, `NEW` star badge, `$` coin, red AI arrow, and pop-up box.
