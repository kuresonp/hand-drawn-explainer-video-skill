# Girl Rig Spec

`templates/remotion-starter/src/components/GirlRig.tsx` is the presenter: an ~18-year-old anime girl with long dark hair,
a red hair clip and ahoge, a red sweater with white collar and bow, a dark-red pleated skirt, white knee socks and brown loafers.
Pure SVG, no Remotion imports: everything derives from the `frame` prop, so it also renders in react-dom/server for stills and tests.

## Coordinates
Local space: feet at `(0,0)`, y grows downward. Head centre `(0,-312)` (rx 32, ry 37), shoulders `y -258` at `x ±29`,
hem `y -128`, total height ~380 (hair tip `-383`). `scale=1` is ~380 px tall on the 720x1280 canvas; `GirlCharacter` places
the feet at `y 1010`. Mirroring (`flip`) scales x by -1, so "right arm" means the arm on screen-right when she faces right.

## Props (`GirlRigProps`)
| Prop | Meaning |
| :--- | :--- |
| `x`, `y`, `scale`, `flip` | placement, size, facing left |
| `frame` | drives blink (every 100 frames), breathing bob, hair sway, thought-dot bounce, tremble |
| `mood` | one of the nine moods |
| `R`, `L` | arm angles `[upper, forearm]` in radians; 0 = right, PI/2 = down; left arm is mirrored automatically |
| `waveR`, `waveL` | adds a sine wobble to that forearm |
| `sweat` | force the sweat drop (auto for shock, worry, scared) |
| `idle` | breathing and hair sway (default true) |

## Moods
`smile`, `happy` (closed ^^ eyes, open smile), `shock` (white eyes, small pupils, round mouth, sweat), `worry` (raised brows, wavy mouth, sweat),
`sad` (brows, frown), `smirk` (half-lidded, one brow up, one-sided grin), `angry` (slanted lids and brows, gritted teeth, red anger mark),
`scared` (tiny pupils, trembling body, zig-zag mouth, sweat), `thinking` (pupils up-and-aside, one brow up, small "o" mouth, thought bubble).

## Arm poses (`ARM_POSES`)
`down`, `point`, `cheer`, `fing` (finger up), `chin` (hand under the chin), `support` (arm across the body under the chin-arm's elbow), `wave`.
For the thinker look use `R: chin`, `L: support`. Angles are for the right arm; to make her think with the other hand, set
`L: chin`, `R: support` and `flip`.

## Drawing order (back to front)
back hair -> legs/socks/shoes -> skirt -> neck -> sweater, collar, bow -> left arm -> right arm -> head -> eyes, blush, nose, mouth,
sweat -> front hair, highlight, ahoge, clip -> brows and mood extras (anger mark, thought bubble).

## Customising
- **Colours:** constants at the top of `GirlRig.tsx` (`HAIR`, `RED`, `DARK_RED`, `SKIRT`, `SKIN`); eye colour is `#C93D5A` in `Eye`.
- **New mood:** add it to the `Mood` union, handle it in `Eye` (eye shape), `Mouth` (mouth), and the brows block at the bottom of `GirlRig`; add it
  to `MOODS` in `scripts/validate_storyboard.mjs` and to the table in `voiceover-to-storyboard-guide.md`.
- **New arm pose:** add `[upper, forearm]` to `ARM_POSES` (solve the two-bone angles: upper arm 55, forearm 52, shoulder at `(±29,-258)`),
  then map a storyboard pose to it in `POSE_ARMS` in `GirlCharacter.tsx` and add the pose name to `CharacterPose` and the validator.
- **Supporting cast:** render another `GirlRig` (or copy it with different `HAIR`/`RED` constants) for side characters; keep the hero red.
- **Line boil:** the rig is wrapped in `<g filter="url(#hand-drawn-boil)">` (done in `Composition.tsx`); the HTML captions are never filtered.
