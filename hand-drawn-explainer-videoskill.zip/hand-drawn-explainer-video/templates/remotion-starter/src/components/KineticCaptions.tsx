import React, { useMemo } from 'react';
import { useCurrentFrame } from 'remotion';
import { WordTiming } from '../types/storyboard';
import { FONT, INK } from './HandDrawnPrimitives';

/** Groups words into lines of 2-4 words (<= 23 characters) so the active pill never wraps. */
export const chunkWords = (words: WordTiming[]): WordTiming[][] => {
  const out: WordTiming[][] = [];
  let cur: WordTiming[] = [];
  let len = 0;
  for (const w of words) {
    if (cur.length >= 4 || (cur.length >= 2 && len + 1 + w.word.length > 23)) {
      out.push(cur);
      cur = [w];
      len = w.word.length;
    } else {
      len += (cur.length ? 1 : 0) + w.word.length;
      cur.push(w);
    }
  }
  if (cur.length) out.push(cur);
  return out;
};

export const KineticCaptions: React.FC<{ words: WordTiming[] }> = ({ words }) => {
  const frame = useCurrentFrame();
  const phrases = useMemo(() => chunkWords(words), [words]);

  // The latest phrase whose first word has started; hidden before the first word and 20 frames after the last.
  let active: WordTiming[] | undefined;
  for (const p of phrases) if (frame >= p[0].startFrame) active = p;
  if (!active) return null;
  const last = phrases[phrases.length - 1];
  if (active === last && frame > last[last.length - 1].endFrame + 20) return null;

  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 84,
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center',
        gap: '10px',
        padding: '0 36px',
      }}
    >
      {active.map((w, i) => {
        const on = frame >= w.startFrame && frame <= w.endFrame;
        const spoken = frame >= w.startFrame;
        return (
          <span
            key={i}
            style={{
              fontFamily: FONT,
              fontSize: 36,
              fontWeight: 600,
              color: INK,
              opacity: spoken ? 1 : 0.28,
              backgroundColor: on ? '#E4C365' : 'transparent',
              padding: '2px 12px',
              borderRadius: 10,
              transform: on ? 'scale(1.06) rotate(-1deg)' : 'scale(1)',
            }}
          >
            {w.word}
          </span>
        );
      })}
    </div>
  );
};
