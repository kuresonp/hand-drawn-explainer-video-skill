import React from 'react';
import { Easing, interpolate, useCurrentFrame } from 'remotion';
import { ARM_POSES, ArmAngles, ArmPose, GirlRig, Mood } from './GirlRig';
import { CharacterExpression, CharacterPose, CharacterPosition, StoryboardBeat } from '../types/storyboard';

export const CHARACTER_X: Record<CharacterPosition, number> = { left: 155, center: 360, right: 565 };
export const CHARACTER_FEET_Y = 1010; // the rig is ~380 px tall -> head top at y ~630, below the prop stage

/** Storyboard pose -> which arm pose each arm takes. */
const POSE_ARMS: Record<CharacterPose, { R: ArmPose; L: ArmPose }> = {
  idle: { R: 'down', L: 'down' },
  point: { R: 'point', L: 'down' },
  'point-left': { R: 'point', L: 'down' },
  'point-right': { R: 'point', L: 'down' },
  'point-up': { R: 'fing', L: 'down' },
  celebrate: { R: 'cheer', L: 'cheer' },
  shocked: { R: 'cheer', L: 'cheer' },
  thinking: { R: 'chin', L: 'support' },
  wave: { R: 'wave', L: 'down' },
};

export const resolveMood = (e: CharacterExpression): Mood => {
  const alias: Record<string, Mood> = { excited: 'happy', worried: 'worry', skeptical: 'smirk', shocked: 'shock' };
  return (alias[e] ?? e) as Mood;
};

export const resolveFacing = (b: StoryboardBeat): 'left' | 'right' => {
  if (b.characterPose === 'point-left') return 'left';
  if (b.characterPose === 'point-right') return 'right';
  if (b.facing) return b.facing;
  return b.characterPos === 'right' ? 'left' : 'right'; // face toward the centre of the frame
};

const arms = (pose: CharacterPose) => {
  const a = POSE_ARMS[pose] ?? POSE_ARMS.idle;
  return { R: ARM_POSES[a.R] as ArmAngles, L: ARM_POSES[a.L] as ArmAngles, waveR: a.R === 'wave', waveL: a.L === 'wave' };
};

const mix = (a: ArmAngles, b: ArmAngles, t: number): ArmAngles => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];

/**
 * Beat-aware wrapper around GirlRig. Slides to the new stage position (14 frames) and eases the arms
 * from the previous beat's pose (10 frames). Render OUTSIDE <Sequence> so `useCurrentFrame()` is global.
 */
export const GirlCharacter: React.FC<{
  beat: StoryboardBeat;
  prev: StoryboardBeat;
}> = ({ beat, prev }) => {
  const frame = useCurrentFrame();
  const local = frame - beat.startFrame;
  const x = interpolate(local, [0, 14], [CHARACTER_X[prev.characterPos], CHARACTER_X[beat.characterPos]], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const t = interpolate(local, [0, 10], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.quad) });
  const a = arms(beat.characterPose);
  const p = arms(prev.characterPose);
  return (
    <GirlRig
      x={x}
      y={CHARACTER_FEET_Y}
      frame={frame}
      mood={resolveMood(beat.characterExpression)}
      R={mix(p.R, a.R, t)}
      L={mix(p.L, a.L, t)}
      waveR={a.waveR}
      waveL={a.waveL}
      flip={resolveFacing(beat) === 'left'}
      sweat={beat.sweatDrop}
    />
  );
};
