import React from 'react';

/**
 * GirlRig — the hero presenter: a stylised ~18-year-old anime girl in a red sweater.
 * Pure SVG, no Remotion imports: everything is derived from the `frame` prop so the
 * same component renders in Remotion, in react-dom/server (stills) and in tests.
 *
 * Local coordinates: feet at (0,0), y grows downward, so the head is around y = -312.
 * At scale 1 she is ~380 px tall on the 720x1280 canvas.
 */

export type Mood =
  | 'smile' | 'happy' | 'shock' | 'worry' | 'sad'
  | 'smirk' | 'angry' | 'scared' | 'thinking';

/** [upper-arm angle, forearm angle] in radians, written for the RIGHT arm.
 *  0 = pointing right, PI/2 = straight down. The left arm is mirrored automatically. */
export type ArmAngles = [number, number];

export const ARM_POSES = {
  down: [1.45, 1.55],
  point: [0.12, 0.04],
  cheer: [-0.75, -1.3],
  fing: [0.55, -1.3],      // finger raised
  chin: [2.332, -1.218],   // hand resting under the chin
  support: [1.1, 3.2],     // arm across the body, supporting the chin-arm's elbow
  wave: [-0.3, -1.2],
} as const satisfies Record<string, ArmAngles>;

export type ArmPose = keyof typeof ARM_POSES;

export interface GirlRigProps {
  x: number;              // feet x on the 720x1280 canvas
  y: number;              // feet y
  frame: number;          // current frame (30 fps)
  mood: Mood;
  R: ArmAngles;           // right arm (character's right = screen right when not flipped)
  L: ArmAngles;           // left arm, same convention, mirrored when drawn
  scale?: number;         // 1 = ~380 px tall
  flip?: boolean;         // mirror horizontally (she faces left)
  sweat?: boolean;        // force a sweat drop
  waveR?: boolean;
  waveL?: boolean;
  idle?: boolean;         // breathing bob + hair sway (default true)
}

const INK = '#1E1B18';
const SKIN = '#FADCBF';
const HAIR = '#2B2230';
const RED = '#E03A3E';
const DARK_RED = '#B82A30';
const SKIRT = '#A82830';

type Pt = [number, number];
const BUBBLE: number[][] = [[86, -424, 28], [64, -418, 18], [110, -416, 20]]; // thought-cloud circles: cx, cy, r
const pts = (p: Pt[]) => p.map(([a, b]) => `${a},${b}`).join(' ');
const Line: React.FC<{ p: Pt[]; w: number; c?: string }> = ({ p, w, c = INK }) => (
  <polyline points={pts(p)} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" />
);

const Ribbon: React.FC<{ x: number; y: number; k?: number }> = ({ x, y, k = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${k})`} stroke={INK} strokeWidth={3} strokeLinejoin="round">
    <path d="M 0 0 L -16 -11 L -16 11 Z" fill={RED} />
    <path d="M 0 0 L 16 -11 L 16 11 Z" fill={RED} />
    <circle r={4.5} fill={DARK_RED} strokeWidth={2.5} />
  </g>
);

const Arm: React.FC<{ sx: number; a: ArmAngles; dir: 1 | -1 }> = ({ sx, a, dir }) => {
  const A = dir > 0 ? a[0] : Math.PI - a[0];
  const B = dir > 0 ? a[1] : Math.PI - a[1];
  const p0: Pt = [sx, -258];
  const p1: Pt = [sx + 55 * Math.cos(A), -258 + 55 * Math.sin(A)];
  const p2: Pt = [p1[0] + 52 * Math.cos(B), p1[1] + 52 * Math.sin(B)];
  const q: Pt = [p1[0] + (p2[0] - p1[0]) * 0.78, p1[1] + (p2[1] - p1[1]) * 0.78];
  return (
    <g>
      <Line p={[p0, p1, q]} w={15} />
      <Line p={[q, p2]} w={12} />
      <Line p={[p0, p1, q]} w={11} c={RED} />
      <Line p={[q, p2]} w={7} c={SKIN} />
      <circle cx={p2[0]} cy={p2[1]} r={6.5} fill={SKIN} stroke={INK} strokeWidth={3} />
    </g>
  );
};

const arc = (cx: number, cy: number, r: number, a0: number, a1: number) =>
  `M ${cx + r * Math.cos(a0)} ${cy + r * Math.sin(a0)} A ${r} ${r} 0 0 1 ${cx + r * Math.cos(a1)} ${cy + r * Math.sin(a1)}`;

const Eye: React.FC<{ d: -1 | 1; mood: Mood; blink: boolean }> = ({ d, mood, blink }) => {
  const ex = d * 14.5;
  const ey = -309;
  if (mood === 'happy' || blink) {
    return <path d={arc(ex, ey + 5, 8, Math.PI * 1.1, Math.PI * 1.9)} fill="none" stroke={INK} strokeWidth={4} strokeLinecap="round" />;
  }
  const k = mood === 'shock' ? 0.78 : mood === 'scared' ? 0.55 : 1;
  const look = mood === 'thinking' ? 'translate(3.5 -3.5)' : undefined;
  const xi = ex - d * 11;
  const xo = ex + d * 11;
  return (
    <g>
      {(mood === 'shock' || mood === 'scared') && <circle cx={ex} cy={ey} r={12.5} fill="#fff" stroke={INK} strokeWidth={2.5} />}
      <ellipse cx={ex} cy={ey} rx={8.5 * k} ry={11.5 * k} fill="#C93D5A" />
      <g transform={look}>
        <ellipse cx={ex} cy={ey + 1.5} rx={4 * k} ry={7 * k} fill="#3A1020" />
        <circle cx={ex - 2.6} cy={ey - 4} r={3 * k} fill="#fff" />
        <circle cx={ex + 2.5} cy={ey + 4.5} r={1.5 * k} fill="#fff" />
      </g>
      {mood === 'smirk' && <rect x={ex - 11} y={ey - 14} width={22} height={11} fill={SKIN} />}
      {mood === 'angry' ? (
        <g>
          <polygon points={pts([[xi, ey - 15], [xo, ey - 15], [xo, ey - 8], [xi, ey - 1]])} fill={SKIN} />
          <Line p={[[xi, ey - 1], [xo, ey - 8]]} w={4.5} />
        </g>
      ) : (
        <Line p={[[ex - 11, ey - 2], [ex - 7, ey - 10], [ex + 4, ey - 12], [ex + 11, ey - 5]]} w={4} />
      )}
    </g>
  );
};

const Mouth: React.FC<{ mood: Mood }> = ({ mood }) => {
  const s = { stroke: INK, strokeWidth: 3, fill: 'none', strokeLinecap: 'round' as const };
  switch (mood) {
    case 'smile': return <path d={arc(0, -290, 6, 0.15 * Math.PI, 0.85 * Math.PI)} {...s} />;
    case 'happy': return <path d="M -7 -289 Q 0 -274 7 -289 Z" {...s} fill="#8C2A3A" />;
    case 'shock': return <ellipse cx={0} cy={-284} rx={4.5} ry={6.5} {...s} fill="#8C2A3A" />;
    case 'worry': return <polyline points={pts([[-7, -285], [-3.5, -288], [0, -285], [3.5, -288], [7, -285]])} {...s} />;
    case 'sad': return <path d={arc(0, -281, 7, 1.15 * Math.PI, 1.85 * Math.PI)} {...s} />;
    case 'angry':
      return (
        <g>
          <rect x={-7} y={-290} width={14} height={8} fill="#fff" stroke={INK} strokeWidth={3} />
          <Line p={[[-2.3, -290], [-2.3, -282]]} w={2} />
          <Line p={[[2.3, -290], [2.3, -282]]} w={2} />
          <Line p={[[-7, -286], [7, -286]]} w={2} />
        </g>
      );
    case 'scared': return <path d="M -8 -286 Q -4 -292 0 -286 Q 4 -292 8 -286 Q 0 -276 -8 -286 Z" {...s} fill="#8C2A3A" />;
    case 'thinking': return <ellipse cx={5} cy={-286} rx={3} ry={2.5} {...s} />;
    default: // smirk
      return (
        <g>
          <path d="M -6 -286 Q 2 -285 8 -292" {...s} />
          <Line p={[[8, -292], [11, -290]]} w={2.5} />
        </g>
      );
  }
};

export const GirlRig: React.FC<GirlRigProps> = ({
  x, y, frame, mood, R, L, scale = 1, flip = false, sweat = false,
  waveR = false, waveL = false, idle = true,
}) => {
  const t = frame / 30;
  const blink = frame % 100 >= 96;
  const sw = idle ? Math.sin(t * 2.2) * 4 : 0;
  const bob = idle ? Math.sin(t * 3) * 1.2 : 0;
  const tremble = mood === 'scared' ? Math.sin(t * 55) * 1.6 : 0;
  const waveAdd = (on: boolean): number => (on ? Math.sin(t * 11) * 0.4 : 0);
  const showSweat = sweat || mood === 'shock' || mood === 'worry' || mood === 'scared';

  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -scale : scale} ${scale})`}>
      <ellipse cx={0} cy={2} rx={50} ry={8} fill="#000" opacity={0.09} />
      <g transform={`translate(${tremble} ${bob})`}>
        {/* back hair */}
        <path
          d={`M -34 -340 C -60 -320 -58 -230 ${-44 + sw} -182 L ${-20 + sw} -190 C -24 -240 -26 -280 -26 -290 L 26 -290 C 26 -280 24 -240 ${20 - sw} -190 L ${44 - sw} -182 C 58 -230 60 -320 34 -340 Z`}
          fill={HAIR} stroke={INK} strokeWidth={4} strokeLinejoin="round"
        />
        {/* legs, knee socks, loafers */}
        {[-12, 12].map((lx) => (
          <g key={lx}>
            <Line p={[[lx, -135], [lx, -18]]} w={14} />
            <Line p={[[lx, -135], [lx, -18]]} w={9} c={SKIN} />
            <Line p={[[lx, -72], [lx, -20]]} w={14} />
            <Line p={[[lx, -72], [lx, -20]]} w={9} c="#fff" />
            <ellipse cx={lx} cy={-9} rx={14} ry={8} fill="#6B3A2A" stroke={INK} strokeWidth={3.5} />
          </g>
        ))}
        {/* pleated skirt */}
        <path d="M -30 -192 L 30 -192 L 54 -128 Q 0 -118 -54 -128 Z" fill={SKIRT} stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        {[-24, -8, 8, 24].map((px) => (
          <Line key={px} p={[[px * 0.5, -188], [px * 1.9, -124]]} w={2.5} c="#7A1C24" />
        ))}
        {/* neck + red sweater */}
        <Line p={[[0, -280], [0, -262]]} w={17} />
        <Line p={[[0, -280], [0, -262]]} w={12} c={SKIN} />
        <path
          d="M -28 -266 L 28 -266 Q 33 -235 24 -210 L 31 -184 L -31 -184 L -24 -210 Q -33 -235 -28 -266 Z"
          fill={RED} stroke={INK} strokeWidth={4} strokeLinejoin="round"
        />
        <Line p={[[-31, -187], [31, -187]]} w={6} c={DARK_RED} />
        <polygon points="-15,-266 0,-246 15,-266" fill="#fff" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
        <Ribbon x={0} y={-246} k={0.6} />
        {/* arms (left first so the chin-arm overlaps the support-arm) */}
        <Arm sx={-29} a={[L[0], L[1] + waveAdd(waveL)]} dir={-1} />
        <Arm sx={29} a={[R[0], R[1] + waveAdd(waveR)]} dir={1} />
        {/* head */}
        <ellipse cx={0} cy={-312} rx={32} ry={37} fill={SKIN} stroke={INK} strokeWidth={4} />
        <Eye d={-1} mood={mood} blink={blink} />
        <Eye d={1} mood={mood} blink={blink} />
        {[-1, 1].map((d) => (
          <ellipse key={d} cx={d * 22} cy={-297} rx={7} ry={3.5} fill="#FF8FA3" opacity={0.45} />
        ))}
        <Line p={[[0, -298], [1.5, -296]]} w={2} />
        <Mouth mood={mood} />
        {showSweat && <path d="M 40 -352 Q 50 -340 40 -334 Q 30 -340 40 -352 Z" fill="#9ED4FF" stroke={INK} strokeWidth={2} />}
        {/* front hair, highlight, ahoge, hair clip */}
        <path
          d="M -34 -312 Q -40 -368 0 -364 Q 40 -368 34 -312 L 32 -292 L 26 -318 L 14 -334 L 2 -326 L -8 -336 L -18 -326 L -26 -332 L -26 -318 L -32 -292 Z"
          fill={HAIR} stroke={INK} strokeWidth={3.5} strokeLinejoin="round"
        />
        <path d="M -22.7 -351.7 A 22 22 0 0 1 -6.5 -361.9" fill="none" stroke="#6A5873" strokeWidth={3} strokeLinecap="round" />
        <Line p={[[0, -363], [-4, -377], [7, -383]]} w={3.5} />
        <Ribbon x={24} y={-352} k={0.8} />
        {/* brows + mood extras */}
        {(mood === 'worry' || mood === 'sad' || mood === 'scared') &&
          [-1, 1].map((d) => <Line key={d} p={[[d * 14.5 + d * 8, -326], [d * 14.5 - d * 8, -332]]} w={3} />)}
        {mood === 'angry' && (
          <g>
            {[-1, 1].map((d) => <Line key={d} p={[[d * 14.5 + d * 9, -332], [d * 14.5 - d * 9, -322]]} w={3.5} />)}
            <g transform="translate(42 -352)">
              {([[1, 1], [-1, 1], [1, -1], [-1, -1]] as Pt[]).map(([a, b], i) => (
                <Line key={i} p={[[a * 2, b * 9], [a * 2, b * 3], [a * 8, b * 3]]} w={3} c="#D5433D" />
              ))}
            </g>
          </g>
        )}
        {mood === 'smirk' && (
          <g>
            <Line p={[[-23, -329], [-6, -328]]} w={3} />
            <Line p={[[6, -340], [23, -336]]} w={3} />
          </g>
        )}
        {mood === 'thinking' && (
          <g>
            <Line p={[[-23, -328], [-6, -326]]} w={3} />
            <Line p={[[6, -334], [23, -337]]} w={3} />
            {BUBBLE.map((b, i) => (
              <circle key={`o${i}`} cx={b[0]} cy={b[1]} r={b[2]} fill="#FBF7EE" stroke={INK} strokeWidth={4} />
            ))}
            {BUBBLE.map((b, i) => (
              <circle key={`f${i}`} cx={b[0]} cy={b[1]} r={b[2] - 2} fill="#FBF7EE" />
            ))}
            <circle cx={44} cy={-368} r={4} fill="#FBF7EE" stroke={INK} strokeWidth={3} />
            <circle cx={56} cy={-384} r={6.5} fill="#FBF7EE" stroke={INK} strokeWidth={3} />
            {[0, 1, 2].map((i) => (
              <circle key={i} cx={72 + i * 14} cy={-424 + Math.sin(t * 4 + i) * 3} r={3.2} fill={INK} />
            ))}
          </g>
        )}
      </g>
    </g>
  );
};
