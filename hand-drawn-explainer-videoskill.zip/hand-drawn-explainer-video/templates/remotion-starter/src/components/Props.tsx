import React from 'react';
import { Easing, interpolate, useCurrentFrame } from 'remotion';
import { CRIMSON, DrawPath, GREEN, INK, PAPER, PopGroup, StarShape, TypeText, wrapText, FONT } from './HandDrawnPrimitives';
import { PropData, StoryboardBeat } from '../types/storyboard';

/**
 * Prop renderers for the upper illustration stage (y 90-580 on the 720x1280 canvas).
 * Every component reads the LOCAL frame, so render them inside <Sequence from={beat.startFrame}>.
 */

const clamp = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
const rectD = (x: number, y: number, w: number, h: number) => `M ${x} ${y} H ${x + w} V ${y + h} H ${x} Z`;

/* ---------- stat-callout: count-up number + label (+ calendar badge) ---------- */
const StatCallout: React.FC<{ d: PropData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const raw = d.statNumber ?? '0';
  const m = raw.match(/[\d,]+(\.\d+)?/);
  const numStr = m ? m[0] : '0';
  const target = parseFloat(numStr.replace(/,/g, '')) || 0;
  const decimals = numStr.includes('.') ? numStr.split('.')[1].length : 0;
  const prefix = m ? raw.slice(0, m.index) : '';
  const suffix = m ? raw.slice((m.index ?? 0) + numStr.length) : '';
  const p = interpolate(frame, [6, 40], [0, 1], { ...clamp, easing: Easing.out(Easing.cubic) });
  const v = (target * p).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return (
    <g>
      <text x={360} y={270} fontSize={104} fontWeight={700} fontFamily={FONT} textAnchor="middle" fill={CRIMSON}>
        {prefix}{v}{suffix}
      </text>
      <DrawPath d="M 170 305 Q 360 320 550 303" delay={30} duration={14} stroke={CRIMSON} strokeWidth={4} />
      <TypeText text={d.statLabel ?? ''} delay={34} x={360} y={370} size={38} />
      {d.badgeText && (
        <g transform="translate(360 480)">
          <PopGroup delay={46}>
            <rect x={-62} y={-52} width={124} height={104} rx={10} fill={PAPER} stroke={INK} strokeWidth={4.5} />
            <path d="M -62 -52 H 62 V -24 H -62 Z" fill={CRIMSON} stroke={INK} strokeWidth={4.5} strokeLinejoin="round" />
            <text x={0} y={-31} fontSize={20} fontWeight={700} fontFamily={FONT} textAnchor="middle" fill="#fff">
              {d.badgeText.toUpperCase()}
            </text>
          </PopGroup>
        </g>
      )}
    </g>
  );
};

/* ---------- headline-card: newspaper with masthead + typewriter headline ---------- */
const HeadlineCard: React.FC<{ d: PropData }> = ({ d }) => {
  const lines = wrapText((d.headline ?? '').toUpperCase(), 16);
  const sub = wrapText((d.subheadline ?? '').toUpperCase(), 16);
  return (
    <g transform="rotate(-2 360 290)">
      <DrawPath d={rectD(90, 110, 540, 370)} duration={20} fill={PAPER} />
      <TypeText text={d.badgeText ?? 'THE DAILY NEWS'} delay={16} x={360} y={165} size={34} />
      <DrawPath d="M 120 185 H 600" delay={22} duration={10} strokeWidth={3} />
      <DrawPath d="M 120 194 H 600" delay={26} duration={10} strokeWidth={3} />
      {lines.map((l, i) => <TypeText key={`h${i}`} text={l} delay={32 + i * 16} x={360} y={250 + i * 54} size={50} cps={30} />)}
      {sub.map((l, i) => (
        <TypeText key={`s${i}`} text={l} delay={40 + lines.length * 16 + i * 14} x={360} y={250 + (lines.length + i) * 54} size={50} fill={CRIMSON} cps={30} />
      ))}
      <DrawPath d={rectD(120, 390, 130, 70)} delay={64} duration={14} fill="#E8DFCE" />
      {[0, 1, 2].map((i) => <DrawPath key={i} d={`M 275 ${398 + i * 24} H 600`} delay={70 + i * 5} duration={10} strokeWidth={3} stroke="#8A8378" />)}
      <g transform="translate(628 112)"><PopGroup delay={78}><StarShape r={26} /></PopGroup></g>
      <g transform="translate(92 478)"><PopGroup delay={84}><StarShape r={22} /></PopGroup></g>
    </g>
  );
};

/* ---------- trend-chart: axes -> curve -> impact star ---------- */
const TrendChart: React.FC<{ d: PropData }> = ({ d }) => {
  const dir = d.trendDirection ?? 'up';
  const rise = 'M 130 440 C 220 425 300 370 400 290 S 480 205 520 190';
  return (
    <g>
      {d.headline && <TypeText text={d.headline} delay={0} x={360} y={120} size={38} />}
      <DrawPath d="M 120 150 V 480 H 630" duration={14} strokeWidth={4} />
      {d.chartLabel && <TypeText text={d.chartLabel} delay={12} x={136} y={178} size={28} anchor="start" />}
      {(dir === 'up' || dir === 'surge') && (
        <DrawPath d={dir === 'surge' ? 'M 130 450 C 300 440 450 400 520 170' : rise} delay={14} duration={34} stroke={GREEN} strokeWidth={8} />
      )}
      {dir === 'down' && <DrawPath d="M 130 190 C 250 200 400 330 590 450" delay={14} duration={34} stroke={CRIMSON} strokeWidth={8} />}
      {dir === 'crash' && (
        <>
          <DrawPath d={rise} delay={14} duration={30} stroke={GREEN} strokeWidth={8} />
          <DrawPath d="M 520 190 L 548 310 L 566 280 L 590 462" delay={48} duration={12} stroke={CRIMSON} strokeWidth={8} />
          <DrawPath d="M 600 210 V 300 M 582 280 L 600 304 L 618 280" delay={58} duration={10} stroke={CRIMSON} strokeWidth={6} />
          <g transform="translate(590 462)"><PopGroup delay={62}><StarShape r={28} fill="#F0A070" /></PopGroup></g>
        </>
      )}
    </g>
  );
};

/* ---------- comparison-scale: beam tips toward the heavier side ---------- */
const ComparisonScale: React.FC<{ d: PropData }> = ({ d }) => {
  const frame = useCurrentFrame();
  const sign = d.heavier === 'left' ? -1 : 1;
  const ang = interpolate(frame, [16, 46], [0, 0.22], { ...clamp, easing: Easing.out(Easing.cubic) }) * sign;
  const ex = 190 * Math.cos(ang);
  const ey = 190 * Math.sin(ang);
  const cx = 360;
  const cy = 250;
  const pan = (dx: number, label: string | undefined, key: string) => {
    const px = cx + dx * ex / 190;
    const py = cy + dx * ey / 190;
    return (
      <g key={key}>
        <path d={`M ${px - 60} ${py + 90} L ${px} ${py} L ${px + 60} ${py + 90}`} fill="none" stroke={INK} strokeWidth={3} />
        <rect x={px - 70} y={py + 88} width={140} height={20} rx={10} fill="#CFC7B8" stroke={INK} strokeWidth={4} />
        <TypeText text={label ?? ''} delay={8} x={px} y={py + 150} size={30} />
      </g>
    );
  };
  return (
    <g>
      <DrawPath d={`M ${cx} ${cy} V 520 M ${cx - 100} 520 H ${cx + 100}`} duration={14} strokeWidth={6} />
      <g transform={`rotate(${(ang * 180) / Math.PI} ${cx} ${cy})`}>
        <DrawPath d={`M ${cx - 190} ${cy} H ${cx + 190}`} delay={6} duration={12} strokeWidth={7} />
      </g>
      <circle cx={cx} cy={cy} r={11} fill="#E4C365" stroke={INK} strokeWidth={4} />
      {pan(-190, d.leftLabel, 'l')}
      {pan(190, d.rightLabel, 'r')}
      {d.badgeText && (
        <g transform={`translate(${cx - sign * 150} 130)`}><PopGroup delay={50}>
          <text x={0} y={0} fontSize={84} fontWeight={700} fontFamily={FONT} textAnchor="middle" fill={CRIMSON}>{d.badgeText}</text>
        </PopGroup></g>
      )}
    </g>
  );
};

/* ---------- warning-storm: cloud + lightning + alert ---------- */
const WarningStorm: React.FC<{ d: PropData }> = ({ d }) => (
  <g>
    <g transform="translate(360 250)">
      <PopGroup delay={4}>
        {[[-70, 10, 48], [-20, -26, 58], [46, -12, 52], [94, 14, 40]].map(([x, y, r], i) => <circle key={i} cx={x} cy={y} r={r} fill="#9D9A96" />)}
        <rect x={-110} y={4} width={220} height={44} rx={22} fill="#9D9A96" />
        <polygon points="10,44 -24,112 -2,112 -18,166 38,88 14,88 32,44" fill="#F5E3A0" stroke={INK} strokeWidth={3.5} strokeLinejoin="round" />
      </PopGroup>
      {[[-70, 72], [64, 92], [-34, 126], [100, 70]].map(([x, y], i) => (
        <DrawPath key={i} d={`M ${x} ${y} l -6 24`} delay={16 + i * 4} duration={8} stroke="#6FA8DC" strokeWidth={5} />
      ))}
    </g>
    <g transform="translate(540 150)"><PopGroup delay={22}>
      <text x={0} y={30} fontSize={110} fontWeight={700} fontFamily={FONT} textAnchor="middle" fill={CRIMSON}>!</text>
    </PopGroup></g>
    {d.headline && <TypeText text={d.headline} delay={30} x={360} y={500} size={40} fill={CRIMSON} />}
  </g>
);

/* ---------- checklist-card: clipboard + staggered checkmarks ---------- */
const ChecklistCard: React.FC<{ d: PropData }> = ({ d }) => {
  const items = (d.items ?? []).slice(0, 5);
  return (
    <g>
      <DrawPath d={rectD(110, 90, 500, 490)} duration={20} stroke={INK} fill="#C99A5B" />
      <DrawPath d={rectD(135, 135, 450, 420)} delay={8} duration={16} fill={PAPER} />
      <DrawPath d={rectD(300, 76, 120, 36)} delay={14} duration={10} fill="#9FADB8" />
      <TypeText text={d.headline ?? ''} delay={20} x={360} y={200} size={42} />
      {items.map((it, i) => {
        const y = 270 + i * 58;
        return (
          <g key={i}>
            <DrawPath d={rectD(165, y - 22, 34, 34)} delay={26 + i * 10} duration={8} strokeWidth={3.5} />
            <DrawPath d={`M 170 ${y - 6} L 181 ${y + 5} L 200 ${y - 24}`} delay={32 + i * 10} duration={8} stroke={GREEN} strokeWidth={6} />
            <TypeText text={it} delay={28 + i * 10} x={215} y={y + 6} size={30} anchor="start" cps={34} />
          </g>
        );
      })}
    </g>
  );
};

/* ---------- process-flow: up to 3 cards joined by arrows ---------- */
const ProcessFlow: React.FC<{ d: PropData }> = ({ d }) => {
  const items = (d.items ?? []).slice(0, 3);
  const w = 190;
  const gap = 20;
  const x0 = (720 - (items.length * w + (items.length - 1) * gap)) / 2;
  return (
    <g>
      {d.headline && <TypeText text={d.headline} delay={0} x={360} y={140} size={40} />}
      {items.map((it, i) => {
        const x = x0 + i * (w + gap);
        const lines = wrapText(it, 11);
        return (
          <g key={i}>
            <DrawPath d={rectD(x, 200, w, 230)} delay={8 + i * 18} duration={14} fill={PAPER} />
            <g transform={`translate(${x + 34} 238)`}><PopGroup delay={18 + i * 18}>
              <circle r={20} fill="#E4C365" stroke={INK} strokeWidth={3.5} />
              <text y={8} fontSize={24} fontWeight={700} fontFamily={FONT} textAnchor="middle" fill={INK}>{i + 1}</text>
            </PopGroup></g>
            {lines.map((l, j) => <TypeText key={j} text={l} delay={22 + i * 18 + j * 6} x={x + w / 2} y={320 + j * 38} size={30} />)}
            {i < items.length - 1 && (
              <DrawPath d={`M ${x + w + 2} 315 H ${x + w + gap - 2} M ${x + w + gap - 10} 305 L ${x + w + gap - 2} 315 L ${x + w + gap - 10} 325`} delay={20 + i * 18} duration={8} strokeWidth={4} />
            )}
          </g>
        );
      })}
    </g>
  );
};

export const PropRenderer: React.FC<{ beat: StoryboardBeat }> = ({ beat }) => {
  const d = beat.propData ?? {};
  switch (beat.propKind) {
    case 'stat-callout': return <StatCallout d={d} />;
    case 'headline-card': return <HeadlineCard d={d} />;
    case 'trend-chart': return <TrendChart d={d} />;
    case 'comparison-scale': return <ComparisonScale d={d} />;
    case 'warning-storm': return <WarningStorm d={d} />;
    case 'checklist-card': return <ChecklistCard d={d} />;
    case 'process-flow': return <ProcessFlow d={d} />;
    default: return null;
  }
};
