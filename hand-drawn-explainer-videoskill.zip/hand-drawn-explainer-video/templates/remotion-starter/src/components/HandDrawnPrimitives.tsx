import React from 'react';
import { Easing, interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';

export const INK = '#1E1B18';
export const CRIMSON = '#D5433D';
export const SAGE = '#AAD39B';
export const GREEN = '#4CA64C';
export const PAPER = '#FBF7EE';
export const FONT = "Fredoka, 'Patrick Hand', 'Comic Sans MS', sans-serif";

export const PaperBackground: React.FC = () => (
  <>
    <defs>
      <radialGradient id="paper-vignette" cx="50%" cy="48%" r="70%">
        <stop offset="0%" stopColor="#EEE4D2" />
        <stop offset="68%" stopColor="#E9DEC9" />
        <stop offset="100%" stopColor="#D3C9B7" />
      </radialGradient>
    </defs>
    <rect x={0} y={0} width={720} height={1280} fill="url(#paper-vignette)" />
  </>
);

/** Line boil: the displacement seed changes every 4 frames (7.5 Hz). Render once inside <defs>. */
export const HandDrawnFilter: React.FC<{ id?: string }> = ({ id = 'hand-drawn-boil' }) => {
  const frame = useCurrentFrame();
  const boilSeed = (Math.floor(frame / 4) % 4) + 1;
  return (
    <filter id={id} x="-8%" y="-8%" width="116%" height="116%">
      <feTurbulence type="fractalNoise" baseFrequency="0.024" numOctaves={2} seed={boilSeed} result="noise" />
      <feDisplacementMap in="SourceGraphic" in2="noise" scale={2.4} xChannelSelector="R" yChannelSelector="G" />
    </filter>
  );
};

/**
 * Pen draw-on. Uses SVG `pathLength={100}` so no manual length maths is needed:
 * dasharray 100, dashoffset 100*(1-progress). Fill fades in after 65% of the stroke.
 */
export const DrawPath: React.FC<{
  d: string;
  delay?: number;
  duration?: number;
  stroke?: string;
  strokeWidth?: number;
  fill?: string;
}> = ({ d, delay = 0, duration = 16, stroke = INK, strokeWidth = 4, fill = 'none' }) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [delay, delay + duration], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const fillOpacity = interpolate(frame, [delay + duration * 0.65, delay + duration + 6], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return (
    <>
      {fill !== 'none' && <path d={d} fill={fill} opacity={fillOpacity} />}
      <path
        d={d}
        fill="none"
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        pathLength={100}
        strokeDasharray={100}
        strokeDashoffset={100 * (1 - progress)}
        opacity={frame >= delay ? 1 : 0}
      />
    </>
  );
};

/** Spring pop-in around the local origin. Wrap in <g transform="translate(x y)"> to place it. */
export const PopGroup: React.FC<{ delay?: number; children: React.ReactNode }> = ({ delay = 0, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const scale = frame < delay ? 0 : spring({ frame: frame - delay, fps, config: { damping: 12, stiffness: 180 } });
  return <g transform={`scale(${scale})`}>{children}</g>;
};

/** Typewriter text. Remaining characters stay in the layout (transparent) so centred text never jitters. */
export const TypeText: React.FC<{
  text: string;
  delay?: number;
  x: number;
  y: number;
  size?: number;
  fill?: string;
  anchor?: 'start' | 'middle' | 'end';
  cps?: number; // characters per second
  weight?: number;
}> = ({ text, delay = 0, x, y, size = 36, fill = INK, anchor = 'middle', cps = 26, weight = 600 }) => {
  const frame = useCurrentFrame();
  const n = Math.max(0, ((frame - delay) * cps) / 30);
  if (n <= 0) return null;
  const k = Math.min(text.length, Math.floor(n));
  return (
    <text x={x} y={y} fontSize={size} fontWeight={weight} fontFamily={FONT} textAnchor={anchor} fill={fill}>
      {text.slice(0, k)}
      {k < text.length && <tspan fillOpacity={Math.min(1, n - k)}>{text.slice(k, k + 1)}</tspan>}
      {k + 1 < text.length && <tspan fillOpacity={0}>{text.slice(k + 1)}</tspan>}
    </text>
  );
};

export const StarShape: React.FC<{ r?: number; fill?: string }> = ({ r = 26, fill = '#E4C365' }) => {
  const p = Array.from({ length: 10 }, (_, i) => {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const d = i % 2 ? r * 0.45 : r;
    return `${(Math.cos(a) * d).toFixed(1)},${(Math.sin(a) * d).toFixed(1)}`;
  }).join(' ');
  return <polygon points={p} fill={fill} stroke={INK} strokeWidth={3.5} strokeLinejoin="round" />;
};

export const wrapText = (text: string, maxChars: number): string[] => {
  const lines: string[] = [];
  let cur = '';
  for (const w of text.split(/\s+/).filter(Boolean)) {
    if (cur && (cur + ' ' + w).length > maxChars) {
      lines.push(cur);
      cur = w;
    } else {
      cur = cur ? cur + ' ' + w : w;
    }
  }
  if (cur) lines.push(cur);
  return lines;
};
