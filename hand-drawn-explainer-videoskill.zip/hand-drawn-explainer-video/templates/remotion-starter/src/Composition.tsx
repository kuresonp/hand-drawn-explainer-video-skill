import React from 'react';
import { AbsoluteFill, Audio, Sequence, useCurrentFrame } from 'remotion';
import { HandDrawnFilter, PaperBackground } from './components/HandDrawnPrimitives';
import { KineticCaptions } from './components/KineticCaptions';
import { GirlCharacter } from './components/GirlCharacter';
import { PropRenderer } from './components/Props';
import { Storyboard } from './types/storyboard';

// Everything inside the SVG (strokes, fills, on-card lettering, the girl) goes through the 7.5 Hz line-boil filter.
// Only the HTML captions below stay crisp: in the reference video the caption zone never changes between boil seeds.

export const HandDrawnExplainer: React.FC<{ storyboard: Storyboard; audioSrc?: string }> = ({ storyboard, audioSrc }) => {
  const frame = useCurrentFrame();
  const { beats, words } = storyboard;

  let idx = beats.findIndex((b) => frame >= b.startFrame && frame < b.endFrame);
  if (idx < 0) idx = frame < beats[0].startFrame ? 0 : beats.length - 1;
  const beat = beats[idx];
  const prev = beats[Math.max(0, idx - 1)];

  const props = beats.map((b) => (
    <Sequence key={b.id} from={b.startFrame} durationInFrames={Math.max(1, b.endFrame - b.startFrame)} layout="none">
      <PropRenderer beat={b} />
    </Sequence>
  ));

  return (
    <AbsoluteFill>
      {audioSrc && <Audio src={audioSrc} />}
      <svg viewBox="0 0 720 1280" style={{ width: '100%', height: '100%' }}>
        <defs>
          <HandDrawnFilter />
        </defs>
        <PaperBackground />
        <g filter="url(#hand-drawn-boil)">{props}</g>
        <g filter="url(#hand-drawn-boil)">
          <GirlCharacter beat={beat} prev={prev} />
        </g>
      </svg>
      <KineticCaptions words={words} />
    </AbsoluteFill>
  );
};
