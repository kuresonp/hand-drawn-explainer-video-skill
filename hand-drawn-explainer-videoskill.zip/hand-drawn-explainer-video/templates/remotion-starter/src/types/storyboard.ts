import type { Mood } from '../components/GirlRig';

export type CharacterPosition = 'left' | 'center' | 'right';

/** High-level arm choreography. The rig turns these into arm angles (see GirlCharacter.tsx). */
export type CharacterPose =
  | 'idle'        // both arms down
  | 'point'       // points the way she faces (toward the prop)
  | 'point-left'  // legacy: point + face left
  | 'point-right' // legacy: point + face right
  | 'point-up'    // finger raised ("here's the thing")
  | 'celebrate'   // both arms up
  | 'shocked'     // both arms up, pair with mood shock / scared
  | 'thinking'    // hand under chin, other arm supporting the elbow
  | 'wave';

/** The rig's native moods, plus the legacy aliases from the stick-figure version. */
export type CharacterExpression =
  | Mood
  | 'excited'   // -> happy
  | 'worried'   // -> worry
  | 'skeptical' // -> smirk
  | 'shocked';  // -> shock

export type PropKind =
  | 'none'
  | 'stat-callout'
  | 'checklist-card'
  | 'comparison-scale'
  | 'trend-chart'
  | 'warning-storm'
  | 'headline-card'
  | 'process-flow';

export interface WordTiming {
  word: string;
  startFrame: number;
  endFrame: number;
}

export interface PropData {
  headline?: string;
  subheadline?: string;
  statNumber?: string;   // e.g. "130,000", "$4.2M", "73%"
  statLabel?: string;
  badgeText?: string;    // masthead (headline-card), unit badge (stat-callout), "?" (comparison-scale)
  leftLabel?: string;
  rightLabel?: string;
  heavier?: 'left' | 'right'; // comparison-scale: which side the beam tips toward (default right)
  chartLabel?: string;
  items?: string[];      // checklist rows or process-flow steps (max 5 / 3)
  trendDirection?: 'up' | 'down' | 'crash' | 'surge';
}

export interface StoryboardBeat {
  id: string;
  startFrame: number;
  endFrame: number;
  narration: string;
  propKind: PropKind;
  propData: PropData;
  characterPos: CharacterPosition;
  characterPose: CharacterPose;
  characterExpression: CharacterExpression;
  facing?: 'left' | 'right'; // default: toward the screen centre; point-left/right override
  sweatDrop?: boolean;
}

export interface Storyboard {
  title: string;
  audioFile?: string; // file name inside public/, e.g. "voiceover.mp3"
  fps: 30;
  width: 720;
  height: 1280;
  totalFrames: number;
  beats: StoryboardBeat[];
  words: WordTiming[];
}
