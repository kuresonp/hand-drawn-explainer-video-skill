import React from 'react';
import { Composition, staticFile } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import { HandDrawnExplainer } from './Composition';
import { Storyboard } from './types/storyboard';
import storyboardJson from './data/storyboard.json';

loadFont();

const storyboard = storyboardJson as unknown as Storyboard;

export const RemotionRoot: React.FC = () => (
  <Composition
    id="HandDrawnExplainer"
    component={HandDrawnExplainer}
    durationInFrames={storyboard.totalFrames}
    fps={30}
    width={720}
    height={1280}
    defaultProps={{
      storyboard,
      audioSrc: storyboard.audioFile ? staticFile(storyboard.audioFile) : undefined,
    }}
    calculateMetadata={({ props }) => ({ durationInFrames: props.storyboard.totalFrames })}
  />
);
