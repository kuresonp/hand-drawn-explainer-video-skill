# Hand-drawn explainer starter (Remotion)

```
npm install
npm run dev        # preview in Remotion Studio (ships with a working example storyboard)
npm run validate   # lint src/data/storyboard.json
npm run render     # -> out/video.mp4  (720x1280, 30 fps)
```
Copy the skill's `scripts/` folder next to this project, then follow `SKILL.md`: transcribe -> word timings -> direct beats -> assemble -> render.
Voice-over goes in `public/voiceover.mp3` and is referenced by `audioFile` in `storyboard.json`.
